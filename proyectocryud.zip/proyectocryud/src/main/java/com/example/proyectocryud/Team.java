package com.example.proyectocryud;

public class Team {
}
