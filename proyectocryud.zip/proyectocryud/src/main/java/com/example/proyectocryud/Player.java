package com.example.proyectocryud;

public class Player extends Person {
}
